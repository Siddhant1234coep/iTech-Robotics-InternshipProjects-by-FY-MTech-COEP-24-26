import socket
import win32com.client as win32
import time
from pywinauto import Application
print("hello")
# === CONFIGURATION ===
HOST = "0.0.0.0"  # Listen on all interfaces
PORT = 5005  # Port to listen on

# === Connect to running PowerPoint ===
try:
    ppt = win32.GetActiveObject("PowerPoint.Application")
    print("✅ Connected to PowerPoint")
except Exception as e:
    print(f"❌ Failed to connect to PowerPoint: {e}")
    exit(1) 

# === Bring PowerPoint to the foreground ===
try:
    app = Application().connect(title_re=".*PowerPoint.*")
    app.top_window().set_focus()
    print("✅ Brought PowerPoint to front")
except Exception as e:
    print(f"⚠️ Could not bring PowerPoint to front: {e}")

# === Wait for presentation to be open ===
presentation = None
for _ in range(50):  # Try for up to 5 seconds
    if ppt.Presentations.Count > 0:
        presentation = ppt.Presentations(1)
        break
    time.sleep(0.1)

if not presentation:
    raise RuntimeError("❌ No PowerPoint presentation is open.")

# === Start the slideshow ===
try:
    slide_show = presentation.SlideShowSettings.Run()
except Exception as e:
    print(f"❌ Failed to start slideshow: {e}")
    exit(1)

# === Get slideshow window ===
show = None
for _ in range(50):  # Wait up to 5 seconds
    if ppt.SlideShowWindows.Count > 0:
        show = ppt.SlideShowWindows(1)
        break
    time.sleep(0.1)

if not show:
    raise RuntimeError("❌ Failed to start slideshow mode.")

total_slides = show.Presentation.Slides.Count
print(f"✅ Presentation ready with {total_slides} slides.")

# === TCP Server to receive commands ===
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((HOST, PORT))
    s.listen(1)
    print(f"📡 Listening for Yanshee on port 5005...")

    conn, addr = s.accept()
    with conn:
        print(f"🔗 Connected by {addr}")
        while True:
            try:
                data = ""
                while True:
                    chunk = conn.recv(1024).decode('utf-8')
                    if not chunk:
                        print("📴 Connection closed by Yanshee")
                        break
                    data += chunk
                    if '\n' in data:
                        break
                if not data:
                    break

                command = data.strip()
                print(f"📥 Received: {command}")

                if command.lower() == "next slide":
                    try:
                        current_slide = show.View.CurrentShowPosition
                        if current_slide < total_slides:
                            # Retry up to 3 times
                            for _ in range(3):
                                show.View.Next()
                                time.sleep(0.1)  # Reduced for faster confirmation
                                new_slide = show.View.CurrentShowPosition
                                if new_slide > current_slide:
                                    print(f"➡️ Moved to slide {new_slide}")
                                    # Send confirmation to Yanshee
                                    conn.sendall("slide {}\n".format(new_slide).encode('utf-8'))
                                    print(f"📤 Sent confirmation: slide {new_slide}")
                                    break
                            else:
                                print(f"⚠️ Failed to move past slide {current_slide} after retries")
                                conn.sendall("error\n".encode('utf-8'))
                        else:
                            print("⛔ Already at last slide.")
                            conn.sendall("error\n".encode('utf-8'))
                    except Exception as e:
                        print(f"⚠️ Error changing slide: {e}")
                        conn.sendall("error\n".encode('utf-8'))
            except Exception as e:
                print(f"⚠️ Error receiving data: {e}")
                break
import YanAPI
import socket
import time

# Configuration
IP_ADDR = "127.0.0.1"  # Replace with your Yanshee robot IP
LAPTOP_IP = "192.168.1.228"  # Replace with your laptop IP
PORT = 5005  # Port for socket communication
TOTAL_SLIDES = 29  # Total slides in the presentation
CONNECTION_RETRIES = 3  # Number of socket connection attempts
RETRY_DELAY = 2  # Seconds to wait between retries
RECEIVE_TIMEOUT = 15  # Seconds to wait for laptop confirmation
CONFIRMATION_RETRIES = 3  # Number of retries for receiving confirmation

# Messages to be spoken
MESSAGES = [
    "Hello",
    "I'm Yanshee, your robotic host for today. Let me introduce you to iTech Robotics & Automation Private Limited — a pioneering name in intelligent automation solutions. Let's begin our journey.",
    "iTech Robotics is a leading engineering company, proudly headquartered in Pune. As a system integrator, we have over 3,500 robot installations, 600 completed projects, and we serve more than 90 clients across India. Our talented team of over 125 professionals drives innovation every day.",
    "Our infrastructure reflects our commitment to excellence. Unit 1, located in Nighoje, spans 40,000 square feet and houses our manufacturing and design operations. Unit 2, located in the Chakan Industrial Area, offers a massive 70,000 square foot shop floor on 3 acres of land.",
    "Our work speaks for itself. We are proud to be trusted by numerous esteemed clients across various industries. Each project is a testament to our reliability and technological prowess.",
    "From arc welding and spot welding automation to customized manipulators, inspection systems, and battery assembly lines — our expertise spans across a wide range of advanced automation solutions. We are also known for developing specialized purpose machines tailored to unique needs. Next these is what we provide at iTech"
]

# Initialize Yanshee API
YanAPI.yan_api_init(IP_ADDR)
print("✅ Yanshee API initialized")

def connect_socket():
    for attempt in range(CONNECTION_RETRIES):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((LAPTOP_IP, PORT))
            s.settimeout(RECEIVE_TIMEOUT)
            print("✅ Connected to laptop")
            return s
        except Exception as e:
            print("⚠️ Connection attempt {} failed: {}".format(attempt + 1, e))
            if attempt < CONNECTION_RETRIES - 1:
                time.sleep(RETRY_DELAY)
    raise Exception("❌ Failed to connect to laptop after {} attempts".format(CONNECTION_RETRIES))

def receive_confirmation(s, expected_slide):
    for attempt in range(CONFIRMATION_RETRIES):
        try:
            data = ""
            start_time = time.time()
            while time.time() - start_time < RECEIVE_TIMEOUT:
                chunk = s.recv(1024)
                if not chunk:
                    raise Exception("Connection closed by laptop")
                data += chunk.decode('utf-8')
                if '\n' in data:
                    break
            if not data:
                raise Exception("No data received")
            
            decoded_data = data.strip()
            print("📥 Received from laptop: {}".format(decoded_data))
            if decoded_data == "slide {}".format(expected_slide):
                return True
            else:
                print("⚠️ Unexpected confirmation: expected 'slide {}', got '{}'".format(expected_slide, decoded_data))
                return False
        except Exception as e:
            print("⚠️ Error receiving confirmation (attempt {}): {}".format(attempt + 1, e))
            if attempt < CONFIRMATION_RETRIES - 1:
                time.sleep(RETRY_DELAY)
    return False

try:
    # Establish socket connection
    s = connect_socket()

    # Step 1: Perform wave motion followed by reset
    success = YanAPI.sync_play_motion(name="wave", direction="right", speed="normal", repeat=1, version="v1")
    print("Wave motion:", "Success" if success else "Failed")
    
    success = YanAPI.sync_play_motion(name="reset")
    print("Reset motion after wave:", "Success" if success else "Failed")

    # Step 2: Speak "Hello" (no slide change)
    YanAPI.sync_do_tts(MESSAGES[0], interrupt=False)
    print("Said: {}".format(MESSAGES[0]))
    time.sleep(1)  # Short pause after "Hello")

    # Step 3: Advance slides and speak messages
    current_slide = 1  # Track current slide (starts at 1)
    for i in range(1, len(MESSAGES)):
        # Speak message first
        YanAPI.sync_do_tts(MESSAGES[i], interrupt=True)
        print("Said: {}".format(MESSAGES[i]))
        
        # Send "next slide" command
        s.sendall(b'next slide\n')
        current_slide += 1
        print("➡️ Sent 'next slide' for slide {}".format(current_slide))
        
        # Wait for laptop confirmation
        if not receive_confirmation(s, current_slide):
            raise Exception("❌ Failed to receive confirmation for slide {}".format(current_slide))
        time.sleep(0.5)  # Brief pause after confirmation

    # Step 4: Advance remaining slides to reach slide 29
    while current_slide < TOTAL_SLIDES - 1:  # Stop at slide 28
        s.sendall(b'next slide\n')
        current_slide += 1
        print("➡️ Sent 'next slide' for slide {}".format(current_slide))
        
        # Wait for laptop confirmation
        if not receive_confirmation(s, current_slide):
            raise Exception("❌ Failed to receive confirmation for slide {}".format(current_slide))
        time.sleep(2)  # 2-second delay between slides

    # Step 5: At slide 29, perform bow, say "Thank you", and reset
    success = YanAPI.sync_play_motion(name="bow", speed="slow")
    print("Bow motion:", "Success" if success else "Failed")
    
    YanAPI.sync_do_tts("Thank you", interrupt=True)
    print("Said: Thank you")
    
    success = YanAPI.sync_play_motion(name="reset")
    print("Reset motion:", "Success" if success else "Failed")

    # Close socket connection
    s.close()
    print("🔌 Connection closed")

except Exception as e:
    print("❌ Error: {}".format(e))
    if 's' in locals():
        s.close()